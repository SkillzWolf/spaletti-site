const PRODUCTS = [
  {id: "p1", title: "Linen Throw Pillow — Sand", price: 49.00, img: "https://picsum.photos/seed/p1/600/400", desc: "Soft linen throw pillow."},
  {id: "p2", title: "Ceramic Table Vase — Olive", price: 68.00, img: "https://picsum.photos/seed/p2/600/400", desc: "Hand-glazed ceramic vase."}
];
document.addEventListener("DOMContentLoaded", () => {document.getElementById("year").textContent = new Date().getFullYear();});